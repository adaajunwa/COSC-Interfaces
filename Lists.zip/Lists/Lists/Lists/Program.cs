﻿//Collections standardize the way objects are handled by our program
// Users can perform operations such as store, update, sort, etc
// In C# COLLECTIONS are divided and used within 3 namespaces
// They are System.Collections, System.Collections.Generic and System.Collections.Concurrent
using System.Collections;

  /*          List<String> food = new List<String>();
            //Add list elements
            food.Add("Pizza");
            food.Add("Chicken");
            food.Add("Rice");
            //Remove element
            food.Remove("Rice");

            //Insert element at a given index
            food.Insert(1, "Fries");

            //Indexof Method returns the index of the given element item
            Console.WriteLine(food.IndexOf("Fries"));

            //Count Method shows the number of items in the list
            Console.WriteLine(food.Count);

            //food.ElementAt()


            //Display items in the food list
            foreach (string item in food)
            {
                Console.WriteLine(item);
            }
*/
           //Create an Array list
            var arrayList = new ArrayList();
            //Add elements of different types
            arrayList.Add(1); // integer
            arrayList.Add(2); // integer
            arrayList.Add("3"); // string
            int sum = 0; //initialize sum to 0
            // Display items in Array list
            foreach (var item in arrayList)
            {
                // convert each item to an integer, add it to the previous
                // and assign it to sum 
                sum += Convert.ToInt32(item);
            }

            Console.WriteLine("Sum is " + sum);// Display sum  
       
//Lists are implemented using arrays in C#. They can resize Dynamically and arrays cannot
//Lists and linked lists both expand dynamically. However, lists store items in continous memory locations
//Linked Lists accept values of same type, but Array lists can accept varied data types
// When memory is an issue, use linked lists over lists
//Linked lists provide better insertion and removal performance, while lists have better direct access performance











            

            



