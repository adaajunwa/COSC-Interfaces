﻿// Create a public genetic interface










public interface IGeneric<T>
{
   
        /// <summary>
        /// Compares  if generic value1 is greater than generic value2
        /// </summary>
        /// <param name="a" and "b">The generic values to be compared</param>
        /// <returns>Generic</returns> 
        T GreaterThan(T a, T b);
    
        
}