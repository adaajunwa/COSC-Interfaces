








//Create a Player class
public class Player
{
    public string Username; //Class Attribute

    public Player(string Username) // Player constructor allows us create
                                   // a class object with arguments
    {
        this.Username = Username; // The allowed class argument
    }
        
}