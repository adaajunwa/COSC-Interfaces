﻿







// Create a generic class that inherits the IGeneric interface
public class EvaluateGreater<T>: IGeneric<int>
{
   //Create a public that compares values a and b
   public int GreaterThan(int a, int b)
   {
      if (a > b) { // if a is greater than b
         // Output a display using string placeholders and return variable a
         Console.WriteLine("{0} is greater than {1}.", a, b);
         return a;
      }
      else
      { // if b is greater than a
         // Output a display and return b
         Console.WriteLine("{0} is less than {1}.", a, b);
         return b;
      }
   } 
}