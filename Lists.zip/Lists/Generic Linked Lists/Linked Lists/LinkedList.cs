//Create a linked list class that implements the ILinked List interface
public class LinkList<T>: ILinkedList<T> //Inherits ILinkedList Interface
{
    public Node<T> first;//The head of the linked list
    
    //Implements the InsertFirst method of ILinkedList: it adds a new node to the
    //beginning of the linked list
    public void InsertFirst(T data) 
    {
        //create the new node
        Node<T> newNode = new Node<T>();
        //Put data in the node
        newNode.Data = data;
        //Make first node the new node's next:
        newNode.Next = first;
        //Make the new node the first node
        first = newNode;
    }

    // DeleteFirst() Implements the DeletesFirst method of ILinkedList
    public Node<T> DeleteFirst() 
    {
        //Assign the first node to a temporary node variable 
        Node<T> Temp = first;
        //Make the next node from the head (first.next) the new head (first)
        first = first.Next;
        return Temp;
    }


    // Implements the DisplayList() method of ILinkedList: Displays the data in the linked list
    public void DisplayList() 
    {
        Console.WriteLine("Iterating through linkedlist...");
        //Assign the first node to a current node variable 
        Node<T> current = first;

        while (current != null) // While the tail has not been reached or linked list empty
        {
            T data = current.Data; // store current node's data in data variable
            Console.WriteLine(data); // display current node's data
            current = current.Next; // Move to next node
        }
    }
}    