﻿
        //Create new LinkeList object
            LinkList<int> l = new LinkList<int>();
            l.InsertFirst(1); //Insert into Linkedlist
            l.InsertFirst(2);//Insert into Linkedlist
            l.InsertFirst(3);//Insert into Linkedlist
            l.InsertFirst(4);//Insert into Linkedlist
            l.DeleteFirst(); //Delete from Linkedlist
            // l.DeleteFirst();
            l.DisplayList(); //Iterate through Linkedlist
            
            
            
            
            
            
            
            


      
    
    