public class Node<T>
{
    // Data to be stored
    public T Data;
    //Next address pointer
    public Node<T> ?Next;
}