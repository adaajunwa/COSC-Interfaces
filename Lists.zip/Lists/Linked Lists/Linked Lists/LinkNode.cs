public class Node
{
    // Data to be stored
    public int Data;
    //Next address pointer
    public Node ?Next;
}