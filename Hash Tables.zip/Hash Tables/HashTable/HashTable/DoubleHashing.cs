﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2
{
    public class DoubleHashTable  
        {
        private const int InitialCapacity = 10;
        private const int DeletedKey = -1;

        private int[] keys;
        private int[] values;
        private int capacity;
        private int size;

        public DoubleHashTable()
        {
            capacity = InitialCapacity;
            keys = new int[capacity];
            values = new int[capacity];
            size = 0;
        }

        private int Hash1(int key)
        {
            return key % capacity;
        }

        private int Hash2(int key)
        {
            return 1 + (key % (capacity - 1));
        }

        private int Probe(int key, int i)
        {
            return (Hash1(key) + i * Hash2(key)) % capacity;
        }

        public void Add(int key, int value)
        {
            if (size >= capacity / 2)
            {
                Resize();
            }

            int index = Hash1(key);
            int i = 0;
            while (keys[index] != 0 && keys[index] != DeletedKey)
            {
                if (keys[index] == key)
                {
                    // Key already exists, update the value
                    values[index] = value;
                    return;
                }
                i++;
                index = Probe(key, i);
            }

            keys[index] = key;
            values[index] = value;
            size++;
        }

        public void Remove(int key)
        {
            int index = FindIndex(key);
            if (index != -1)
            {
                keys[index] = DeletedKey;
                values[index] = 0;
                size--;
            }
        }

        public String Find(int key)
        {
            int index = FindIndex(key);
            if (index != -1)
            {
                return values[index] + "";
            }
            else
            {
                return "Key not found";
            }
        }

        private int FindIndex(int key)
        {
            int index = Hash1(key);
            int i = 0;
            while (keys[index] != 0)
            {
                if (keys[index] == key)
                {
                    return index;
                }
                i++;
                index = Probe(key, i);
            }
            return -1;
        }

        private void Resize()
        {
            int newCapacity = capacity * 2;
            int[] newKeys = new int[newCapacity];
            int[] newValues = new int[newCapacity];

            for (int i = 0; i < capacity; i++)
            {
                if (keys[i] != 0 && keys[i] != DeletedKey)
                {
                    int key = keys[i];
                    int value = values[i];
                    int newIndex = Hash1(key);
                    int j = 0;
                    while (newKeys[newIndex] != 0)
                    {
                        j++;
                        newIndex = Probe(key, j);
                    }
                    newKeys[newIndex] = key;
                    newValues[newIndex] = value;
                }
            }

            keys = newKeys;
            values = newValues;
            capacity = newCapacity;
        }
    }
}