﻿interface IPredator
{
    /// <summary>
    /// Displays a predator related message to the console
    /// </summary>
    /// <returns>void</returns> 
    void Hunt();
}