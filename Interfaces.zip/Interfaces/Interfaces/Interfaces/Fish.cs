﻿//create class Bird that uses the IPrey interface
class Fish : IPrey, IPredator //Class Bird inherits from
                              //the IPrey and Ipredator interfaces
{
    public void Flee() //Method Flee displays a prey related message 
    {
        Console.WriteLine("The fish runs away");// Display to console
    }
        
    public void Hunt() //Method Flee displays a predator related message 
    {
        Console.WriteLine("The fish hunts other fish");// Display to console
    }
        
}