﻿// See https://aka.ms/new-console-template for more information
 
        //Create new Bird object
        Bird bird = new Bird();
        bird.Flee(); // Call the bird's Flee method
        Fish fish = new Fish(); //Create a new Fish object
        fish.Flee(); // Call the fish' Flee method
        fish.Hunt(); // Call the fish' Hunt method
        
 