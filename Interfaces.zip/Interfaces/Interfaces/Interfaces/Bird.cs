﻿//create class Bird that uses the IPrey interface
// As a rule of thumb in ADTs, public-facing methods must use interfaces
class Bird : IPrey //Class Bird inherits from the IPrey interface
{
    public void Flee()//Method Flee displays a prey related message 
    {
        Console.WriteLine("The bird runs away");//Display to console
    }
}