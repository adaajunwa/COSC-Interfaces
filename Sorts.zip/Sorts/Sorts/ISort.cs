﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;




public interface ISort
{
    /// <summary>
    /// Performs an insertion sort on elements in an array
    /// </summary>
    /// <param name="a">The array to be sorted</param>
    /// <returns>void</returns>
    void InsertionSort(int[] a);

    /// <summary>
    /// Performs a quick sort on elements in an array
    /// </summary>
    /// <param name="a">The array to be sorted</param>
    /// <returns>void</returns>
    void QuickSort(int[] a);

    /// <summary>
    /// Performs a heap sort on elements in an array
    /// </summary>
    /// <param name="a">The array to be sorted</param>
    /// <returns>void</returns>
    void HeapSort(int[] a);
}