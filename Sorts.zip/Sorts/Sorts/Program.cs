﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

Sorts sort = new Sorts();
int[] a = { 0,1,5, 9,10, 5, 2,7,13, 3};
//sort.HeapSort(a);
//sort.QuickSort(a);
sort.InsertionSort(a);
foreach (var item in a)
{
    Console.WriteLine(item);
}
