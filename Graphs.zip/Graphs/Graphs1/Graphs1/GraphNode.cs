﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Class for the graph's vertice
public class GraphNode
{
    public string data; // Vertice's data is of type string

    // Constructor for the Graph class
    public GraphNode(string data)
    {
        this.data = data;
    }

}