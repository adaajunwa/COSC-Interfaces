﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Class for the graph - implements a graph using the List data structure
public class Graph
{
    public List<GraphNode> nodes;// Declare a list to hold the graph vertices
    int[,] matrix;// Declare a 2 dimentional matrix to store the edge references

    //Constructor for the graph
    public Graph(int size)
    {
        nodes = new List<GraphNode>();// Instantiate a list of vertices
        matrix = new int[size, size];// instantiate a V*V matrix, where V is number of vertices in Graph
    }

    //Implements the addNode method in the IGraph interface; Adds a vertice node to the list
    public void addNode(GraphNode node)
    {
        nodes.Add(node);//Adds a vertice node to the list

    }

    //Implements the addEdge method in the IGraph interface; Adds an edge representation to the matrix
    public void addEdge(int src, int dest)
    {
        matrix[src, dest] = 1; //Insert 1 into the corresponding matrix' row and column
    }

    //Implements the addEdgeWeight method in the IGraph interface; Adds an edge weight to the matrix
    public void addEdgeWeight(int src, int dest, int weight)
    {
              matrix[src, dest] = weight; //Insert weight into the corresponding matrix' row and column
    }


    //Implements the checkEdge method in the IGraph interface; checks if an edge exists in the matrix
    public void checkEdge(int src, int dest)
    {
        if (matrix[src, dest] != 0)// if matrix element is not 0
             Console.WriteLine("Edge " + matrix[src, dest] + " exists");// Display message that edge with said representation/ weight exists
        else //else if matrix element is 0
            Console.WriteLine("Edge does not exist"); // Display message that does not exist
    }


    //Implements the display method in the IGraph interface; displays the Vertice Nodes and Matrix representation of the edges.
    public void display()
    {
        Console.Write("  ");// Add 2 spaces to align matrix column headers on the same line
        foreach (GraphNode graphNode in nodes)// for each vertice node in the list
        {
            Console.Write(graphNode.data + " "); //Display vertice node's data and a space on the same line
        }
        Console.WriteLine(); //enter a new line

        for (int i = 0; i < matrix.GetLength(0); i++)// While i is less than the matrix row lenght, increment i by 1
        {
            Console.Write(nodes[i].data + " ");// Display list index i's data and a space on the same line 
            for (int j = 0; j < matrix.GetLength(1); j++)// While j is less than the matrix column lenght, increment i by 1
                                                         // For loop displays each matrix row
            {
                Console.Write(matrix[i, j] + " ");// Display matrix' data at row i and column j, and a space on the same line
            }
            Console.WriteLine(); //enter a new line
        }
    }

}