﻿Graph graph = new Graph(5);

graph.addNode(new GraphNode("A"));
graph.addNode(new GraphNode("B"));
graph.addNode(new GraphNode("C"));
graph.addNode(new GraphNode("D"));
graph.addNode(new GraphNode("E"));

graph.addEdge(0, 1);
graph.addEdge(1, 2);
graph.addEdge(1, 4);
graph.addEdge(2, 3);
graph.addEdge(2, 4);
graph.addEdge(4, 0);
graph.addEdge(4, 2);

graph.display();

Console.WriteLine();

graph.checkEdge(0,4);