﻿
//Create Binary Tree Node Class
public class Node
{
     
    public Node LeftNode { get; set; } //Left child
    public Node RightNode { get; set; } //Right child
    public int Data { get; set; } //Content of node
     
}