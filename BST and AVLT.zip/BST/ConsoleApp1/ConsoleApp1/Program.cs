﻿
//Creates a Binary_Tree object
Binary_Tree b = new Binary_Tree();
b.Add(15); //Add a node
b.Add(12); //Add a node
b.Add(21); //Add a node
b.Add(11); //Add a node
b.Add(22); //Add a node
b.Add(20); //Add a node
b.TraverseInOrder(b.Root); //Iterate through the Binary Tree inorder transversal
Console.WriteLine("\n"+b.GetTreeHeight()); //Display height of Binary Tree
Console.WriteLine(b.MinValue(b.Root)); //Find the minimum value in the tree, starting at the root node
b.Find(15); //Search for node 15
//b.Remove(15);

Console.WriteLine("Hello, World!");

AVL tree = new AVL();
tree.Add(3);
tree.Add(1);
tree.Add(2);
tree.Add(4);
//tree.Add(2);
// tree.Delete(7);
Console.WriteLine(tree.getHeight(tree.root));
Console.WriteLine(tree.root.data);
Console.WriteLine(tree.root.left.data);
Console.WriteLine(tree.root.right.data);
Console.WriteLine(tree.root.right.right.data);
tree.InOrderDisplayTree(tree.root);


