﻿// See https://aka.ms/new-console-template for more information

Console.WriteLine("Hello, World!");

AVL tree = new AVL();
tree.Add(3);
tree.Add(1);
tree.Add(2);
// tree.Delete(7);
Console.WriteLine(tree.getHeight(tree.root));
Console.WriteLine(tree.root.data);
Console.WriteLine(tree.root.left.data);
Console.WriteLine(tree.root.right.data);
//Console.WriteLine(tree.root.right.right.data);
tree.DisplayTree();
      
    

    
