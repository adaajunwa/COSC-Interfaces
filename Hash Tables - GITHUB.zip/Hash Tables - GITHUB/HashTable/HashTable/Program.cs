﻿// See https://aka.ms/new-console-template for more information

using System;
using System.Collections;
using System.Security.Cryptography.X509Certificates;

/*
HashTable<int, string> names = new HashTable<int, string>();
names.AddOrUpdate(1, "One");
names.AddOrUpdate(2, "Two");
names.AddOrUpdate(13, "Thirteen");
names.AddOrUpdate(23, "Twenty three");
names.AddOrUpdate(33, "Thirty three");

//Console.WriteLine("123".GetHashCode());

Console.WriteLine("...in Separate Chaining Hash Table.....");
Console.WriteLine(names.TryGetValue(13));
//Console.WriteLine(names.TryGetValue(4));
Console.WriteLine(names.TryGetValue(23));
//Console.WriteLine(names.TryGetValue(13));

names.AddOrUpdate(13, "UNO");
Console.WriteLine(names.TryGetValue(13));

names.Remove(13);
//Console.WriteLine(names.TryGetValue(33));
//Console.WriteLine(names.TryGetValue(13));

*/





OpenAddress lo = new OpenAddress();
lo.linearInsert(1, 5);
lo.linearInsert(2, 15);
lo.linearInsert(3, 20);
lo.linearInsert(12, 30);
lo.linearInsert(23, 50);

Console.WriteLine("...in Open Addressing Linear Probe Hash Table.....");
lo.linearFind(23);
//lo.linearDeleteKey(1);
//lo.linearInsert(11, 55);
//lo.linearFind(11);

Console.WriteLine("...in Open Addressing Quadratic Probe Hash Table.....");
lo.insertQuard(13, 7);
lo.insertQuard(53, 100);
lo.insertQuard(43, 60);
//Console.WriteLine(lo.deleteQuard(13));
//lo.insertQuard(13, 7);

















